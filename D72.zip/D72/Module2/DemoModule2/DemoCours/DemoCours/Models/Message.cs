﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using DemoCours.Ressource;

namespace DemoCours.Models
{
    public class Message
    {
        [Display(Name="Emetteur",ResourceType =typeof(ResourceView))]
        public string Emetteur { get; set; }
        [Display(Name = "Contenu", ResourceType = typeof(ResourceView))]
        public string Contenu { get; set; }
        [Display(Name = "Date de création du message")]
        public DateTime Date { get; set; }

        public Message(string aEmetteur, string aContenu, DateTime aDate)
        {
            Emetteur = aEmetteur;
            Contenu = aContenu;
            Date = aDate;

        }

        public Message() {;}

        public override string ToString()
        {
            return "Emetteur" + Emetteur + "  Contenu" + Contenu + "   Date" + Date;
        }
    }
}